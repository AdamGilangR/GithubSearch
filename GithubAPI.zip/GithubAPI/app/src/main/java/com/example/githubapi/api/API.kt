package com.example.githubapi.api


import com.example.githubapi.data.model.DetailUserResponse
import com.example.githubapi.data.model.User
import com.example.githubapi.data.model.UserResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query

interface API {
    @GET("search/users")
    @Headers("Authorization: token 53ff3d99e2d0cec0e87ff0ba6af6ebfd0967d9a6")
    fun getSearchUser(
        @Query("q") query: String
    ): Call<UserResponse>

    @GET("users/{username}")
    @Headers("Authorization: token 53ff3d99e2d0cec0e87ff0ba6af6ebfd0967d9a6")
    fun getUserDetail(
        @Path("username") username : String
    ): Call<DetailUserResponse>

    @GET("users/{username}/followers")
    @Headers("Authorization: token 53ff3d99e2d0cec0e87ff0ba6af6ebfd0967d9a6")
    fun getFollowers(
        @Path("username") username : String
    ): Call<ArrayList<User>>

    @GET("users/{username}/following")
    @Headers("Authorization: token 53ff3d99e2d0cec0e87ff0ba6af6ebfd0967d9a6")
    fun getFollowing(
        @Path("username") username : String
    ): Call<ArrayList<User>>
}
