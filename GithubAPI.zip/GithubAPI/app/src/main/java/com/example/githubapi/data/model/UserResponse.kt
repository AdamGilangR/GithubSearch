package com.example.githubapi.data.model

data class UserResponse (
    val items : ArrayList<User>
)